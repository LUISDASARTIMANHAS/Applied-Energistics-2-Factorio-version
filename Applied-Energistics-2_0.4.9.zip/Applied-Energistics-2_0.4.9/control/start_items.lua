-- Importando as funções do arquivo functions.lua
require("functions")

-- Altere o nome da função para algo mais descritivo
function adicionarItensAoAndar(event)
    local player = game.players[event.player_index]
    if player and player.valid then
        -- Itens iniciais que você deseja fornecer ao jogador
        local startingItems = {
            {name = "iron-plate", count = 100},
            {name = "copper-plate", count = 100},
            {name = "iron-gear-wheel", count = 50},
            -- Adicione mais itens conforme necessário
        }

        -- Adiciona os itens ao jogador
        for _, item in pairs(startingItems) do
            AdicionarItemNaMochilaDoJogador(player, item.name, item.count)
        end
    end
end

-- Registre a função para o evento on_player_changed_position
script.on_event(defines.events.on_player_changed_position, adicionarItensAoAndar)
