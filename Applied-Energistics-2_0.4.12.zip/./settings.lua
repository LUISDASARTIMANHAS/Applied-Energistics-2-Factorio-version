data:extend({
    {
        type = "bool-setting",
        name = "mute",
        setting_type = "startup",
        localised_name = "AE2-mute",
        default_value = false
    },
    {
        type = "bool-setting",
        name = "AE2_legacy_resources",
        setting_type = "startup",
        localised_name = "AE2-legacy-resources",
        default_value = false
    },
})
