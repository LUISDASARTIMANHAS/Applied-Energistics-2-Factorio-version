require("control/functions")

-- script.on_event(defines.events.on_player_changed_position, AddLegacyResources())