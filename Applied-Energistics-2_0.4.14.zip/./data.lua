-- presets Basicos do mods
require("data.AE2_grupos")
-- require("control/certus-quartz-crystal.lua")
-- require("control/cubo-misterioso.lua")

-- recursos
require("data.ores")

-- receitas
require("data.processors")
require("data.items")

-- pesquisas
require("data/pesquisa/AE2_pesquisa.lua")

-- blocos
-- require("data/blocos/1k_crafting_storage.lua")
-- require("data/blocos/4k_crafting_storage.lua")
-- require("data/blocos/16k_crafting_storage.lua")
-- require("data/blocos/64k_crafting_storage.lua")
-- require("data/blocos/cable_pattern_provider.lua")
-- require("data/blocos/crafting_co_processing_unit.lua")
-- require("data/blocos/crafting_monitor.lua")
-- require("data/blocos/crafting_terminal.lua")
-- require("data/blocos/crafting_unit.lua")
-- require("data/blocos/drive.lua")
-- require("data/blocos/inscriber.lua")
-- require("data/blocos/interface.lua")
-- require("data/blocos/molecular_assembler.lua")
-- require("data/blocos/pattern_access_terminal.lua")
-- require("data/blocos/pattern_provider.lua")
-- require("data/blocos/storage_monitor.lua")
-- require("data/blocos/terminal.lua")
